"""
Task 8: Remove duplicates from a list without using set(), 
while preserving the original order
(Same as Task 5)
"""

def remove_duplicates(numbers):
    """
    Removes duplicates from a list without using set(),
    while preserving the original order.
    """
    seen = []
    result = []
    
    for num in numbers:
        if num not in seen:
            seen.append(num)
            result.append(num)
    
    return result

# Example
numbers = [4, 2, 4, 5, 2, 3, 5, 1]
output = remove_duplicates(numbers)

print(f"Input: {numbers}")
print(f"Output: {output}")

