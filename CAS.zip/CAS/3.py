"""
Task 3: Print the transpose of a 2D list (matrix)
"""

def transpose_matrix(matrix):
    """
    Transposes a 2D matrix (list of lists).
    Returns the transpose of the matrix.
    """
    if not matrix:
        return []
    
    # Get dimensions
    rows = len(matrix)
    cols = len(matrix[0])
    
    # Create transposed matrix
    transposed = []
    for j in range(cols):
        new_row = []
        for i in range(rows):
            new_row.append(matrix[i][j])
        transposed.append(new_row)
    
    return transposed

# Example
input_matrix = [[1, 2], [3, 4], [5, 6]]
output = transpose_matrix(input_matrix)

print(f"Input: {input_matrix}")
print(f"Output: {output}")

