"""
Task 4: Reverse the order of words in a string
"""

def reverse_words(sentence):
    """
    Reverses the order of words in a string.
    Returns the reversed sentence.
    """
    words = sentence.split()
    reversed_words = words[::-1]  # Reverse the list of words
    return " ".join(reversed_words)

# Example
input_text = "hello world python"
output = reverse_words(input_text)

print(f"Input: \"{input_text}\"")
print(f"Output: \"{output}\"")

