"""
Task 1: Find all elements appearing in both lists (duplicates allowed only once)
"""

def find_common_elements(list1, list2):
    """
    Finds all elements appearing in both lists.
    Duplicates are allowed only once in the result.
    """
    # Convert to sets to find intersection, then convert back to list
    result = list(set(list1) & set(list2))
    return sorted(result)  # Sort for consistent output

# Example
List1 = [1, 2, 3, 4]
List2 = [3, 4, 5, 6]

output = find_common_elements(List1, List2)
print(f"List1 = {List1}")
print(f"List2 = {List2}")
print(f"Output -> {output}")

