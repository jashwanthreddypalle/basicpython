"""
Task 2: Count how many times each word appears in a sentence
"""

def count_words(sentence):
    """
    Counts how many times each word appears in a sentence.
    Returns a dictionary with word counts.
    """
    words = sentence.split()
    word_count = {}
    
    for word in words:
        word_count[word] = word_count.get(word, 0) + 1
    
    return word_count

# Example
input_text = "the cat and the hat"
output = count_words(input_text)

print(f"Input: \"{input_text}\"")
print(f"Output: {output}")

