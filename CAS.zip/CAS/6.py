"""
Task 6: Find all unique pairs that add up to a target sum
"""

def find_pairs(numbers, target_sum):
    """
    Finds all unique pairs that add up to the target sum.
    Returns a list of tuples.
    """
    pairs = []
    n = len(numbers)
    
    # Check all pairs
    for i in range(n):
        for j in range(i + 1, n):
            if numbers[i] + numbers[j] == target_sum:
                pair = tuple(sorted([numbers[i], numbers[j]]))
                # Add only if not already in pairs
                if pair not in pairs:
                    pairs.append(pair)
    
    return pairs

# Example
numbers = [2, 4, 3, 5, 7, 8, -1]
target_sum = 6
output = find_pairs(numbers, target_sum)

print(f"List -> {numbers}")
print(f"Target sum -> {target_sum}")
print(f"Output -> {output}")

